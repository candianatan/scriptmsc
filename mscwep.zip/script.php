<html xmlns="http://www.w3.org/1999/xhtml" class=" js cssanimations"><head> 
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
  <meta name="MSC VIP" content="true"> 
  <meta name="viewport" content="width=320 ,user-scalable=no"> 
  <meta name="description" content="Web MSC"> 
  <meta name="keywords" content="VPS , PAYLOAD, DROPLET, APK, SCRIPT MSV, ETC"> 
  <meta name="author" content="MSC | VIP"> 
  <title>MSC PERÚ | VPS</title> 
  <link href="../../css/estilos.css" rel="stylesheet" type="text/css"> 
  <style type="text/css">
<!--
* { margin:0; padding:0;}
img, fieldset, abbr {
	border:none;
}
ul,li{ list-style-type:none}
h1,h2,h3,h4,h5,h6 { font-size:1em;}
acronym, abbr { border-bottom: 1px dotted #333;cursor:help;}

body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}

.tabla_precios {
	max-width:100%;
	}
-->
</style> 
  <style type="text/css">#efectosCont .transp{position:absolute;left:0em;top:0em;width:100%;background-color:#000;height:100em;z-index:1000;font-size:1.3em;opacity:0.8; filter: alpha(opacity=80)}
</style> 
  <style>.contentsuperdestacados { background:transparent; height:27.2em;}.tpSubMenu .lstRight .txt { filter:progid:dximagetransform.microsoft.alpha(opacity=80); moz-opacity:0.8; opacity:0.8;}ul.othersLanguages { display:none; position:absolute; left:0; top:3.6em; width:7em; padding:1em; z-index:20; border:1px solid #48b1c7; border-top:0;}ul.othersLanguages li { float:none; margin-bottom:.5em;}.headercabecera h1.bold, .headercabecera h1.boldPeque, .headercabecera h1.reg, .headercabecera h1.prodbold, .headercabecera h1.prodreg { font-size:37px;}.contentcatalogo .destacados { height:25.3em; overflow:hidden}.intapoyo, .intlomasbuscado, .online { display:none;}.ocultaTabs { display:none;}.cabecera_producto .precioproducto span.titPuntos { display:none;}#gmap_coberturaWifi_op { display:none;}.cobertura_finder .ciudad { display:inline;}.cobertura_finder .lista_ejemplos {display:none;}.oculta_R, #wrapper .oculta_R,.descripVideo { display:none;}.cerrar_share { visibility:visible !important;}.form_ordenar .goTo, .detalles_producto,.toggle_hide { display:none;}.detalles_producto { display:none; position:static }.personalizacion .footer_personalizacion span { color:#fff }.list_prod_contratados .footer_prod_cont { display:block }.carrusel_ficha_prod .item-list ul {overflow:hidden}.rightcomunidad .plegado .tr {padding-bottom:0;} .rightcomunidad .plegado .archivo_blog ul {display:none} .rightcomunidad .plegado .archivo_blog h2 {background-image:url(../img/ico_arrowblue_r.gif);}.intconfigpuesto .n-ordenadores{height:8em;}</style> 
  <link href="../css/estilos.css" rel="stylesheet" type="text/css"> 
 </head> 
 <body>
  <div class="ns-box ns-other ns-effect-thumbslider ns-type-notice ns-show">
   <div class="ns-box-inner">
    
    <div class="ns-content">
     
    </div>
   </div>
   <span class="ns-close"></span>
  </div> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
   <tbody>
    <tr> 
     <td>

      <link rel="stylesheet" type="text/css" href="#"> 
      <link rel="stylesheet" type="text/css" href="/m/css/ns-style-other.css"> <style type="text/css">
<!--
.style1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #FFFFFF;
}

	a.arial_12_cabezal:link {
	font: 12px Verdana, Arial, Helvetica, sans-serifl;color: #ffffff; text-decoration:none; }
a.arial_12_cabezal:hover {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #ffffff;text-decoration:underline; }	
a.arial_12_cabezal:visited {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #ffffff;text-decoration:underline; }
a.arial_12_cabezal:hover {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #ffffff;text-decoration:underline; }	
	
		a.arial_12_cabezal_azul:link {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #55c8e3; text-decoration:none; }
a.arial_12_cabezal_azul:hover {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #55c8e3;text-decoration:underline; }	
a.arial_12_cabezal_azul:visited {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #55c8e3;text-decoration:underline; }
a.arial_12_cabezal_azul:hover {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #55c8e3;text-decoration:underline; }	
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style> 
      <table width="100%" height="37" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 

       <td width="34%" align="center" bgcolor="#004262" class="arial_12_cabezal_azul"><a href="vpsmsc.php" class="arial_12_cabezal_azul">MSC</a></td>




         <td width="2"><img src="#" width="2" height="39"></td> 


        
 
   <td width="34%" align="center" bgcolor="#00527a"><a href="script.php" class="arial_12_cabezal">SCRIPT</a></td> 




         <td width="2"><img src="#" width="2" height="39"></td> 

  <td width="34%" align="center" bgcolor="#004262" class="arial_12_cabezal_azul"><a href="mscssh.php" class="arial_12_cabezal_azul">SSH MSC </a></td>


         
        </tr> 
       </tbody>
      </table> 
      <table width="100%" bgcolor="#00537B" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td width="52" bgcolor="#00537B"><a hre="#"><img src="img/vip.png" width="52" height="52" border="0"></a></td> 
         <td width="669">
          <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
           <tbody>
            <tr> 
             <td width="137" height="52" align="center" bgcolor="#00537B">&nbsp;</td> 
            </tr> 
           </tbody>
          </table></td> 
         <td width="131" align="right" bgcolor="#00537B"><a hre="#"><img src="img/vip.png" width="52" height="52" border="0"></a></td> 
        </tr> 
       </tbody>
      </table> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td width="10" height="37" bgcolor="#00334e">&nbsp;</td> 
         <td bgcolor="#00334e"><span class="style1"><center>$~MSC VIP PERÚ~$</center></span></td> 
          
          
          
         <td width="10" bgcolor="#00334e">&nbsp;</td> 
        </tr> 
       </tbody>
      </table> <script>
			
					var notification = new NotificationFx({
						message : '<div class="ns-thumb"><img src="#"/></div><div class="ns-content"><p><a href="#" id="recbutton" onClick="pageTracker._trackEvent(\'express__\',\'clic\',\'flotante__boton__recarga\');"><img src="#"></a></p></div>',
						layout : 'other',
						ttl : 6000,
						effect : 'thumbslider',
						type : 'notice', // notice, warning, error or success
						onClose : function() {
							
						}
					});

					// show the notification
					notification.show();

			
</script> </td> 
    </tr> 
    <tr>
     <td> <style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style> </td>
    </tr>
    <tr> 
     <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td height="8" bgcolor="#8cb336"></td> 
        </tr> 
        <tr> 
         <td height="2" bgcolor="#6fa627"></td> 
        </tr> 
        <tr> 
         <td height="80px">
          <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
           <tbody>
            <tr style="height:80px;"> 
             <td width="25%" align="center" background="#" bgcolor="#00537B"><a href="https://chat.whatsapp.com/HWyspWXBOzp4XOuvdfgZiv"><img src="img/what.png" width="60" align="top" height="60" border="0"></a></td> 
             
<td><img src="borde" width="2" height="80"></td> 

               <td width="25%" align="center" background="#" bgcolor="#00537B"><a href="https://www.facebook.com/groups/116823142324222/"><img src="img/face.png" width="63" align="top" height="63" border="0"></a></td> 



   <td><img src="borde" width="2" height="80"></td> 

             <td width="25%" align="center" background="#" bgcolor="#00537B"><a href="https://www.youtube.com/channel/UCMfN61m6Y5El5nhtAYZy1pw"><img src="img/youtu.png" width="55" align="top" height="55" border="0"></a></td> 

       
<td><img src="borde" width="2" height="80"></td> 


               <td width="25%" align="center" background="#" bgcolor="#00537B"><a href="https://www.youtube.com/channel/UCMfN61m6Y5El5nhtAYZy1pw"><img src="img/btc.png" width="63" align="top" height="63" border="0"></a></td> 



            </tr> 
           </tbody>
          </table> </td> 
        </tr> 
        <tr> 
         <td height="8" bgcolor="#8cb336"></td> 
        </tr> 
        <tr> 
         <td height="2" bgcolor="#6fa627"></td> 
        </tr> 
        <tr> 
         <td height="1" bgcolor="#FFFFFF"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
   </tbody>
  </table> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
   <tbody>
    <tr> 
     <td>
      <table width="100%" bgcolor="#D4E2E5" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td width="5%" height="38" bgcolor="#D4E2E5"><a href="#"></a></td> 
         <td width="11%" height="38" align="center" bgcolor="#D4E2E5"></td> 
         <td width="69%" align="center" bgcolor="#D4E2E5" class="titulos_detalle_planes">MSC</td> 
         <td width="15%" align="center" bgcolor="#D4E2E5"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
    <tr> 

     <td colspan="2">
      <marquee scrollamount="10" behavior="alternate"> 
  <h1>ENTEL BITEL CLARO</h1> 
 </marquee>





    <tr> 
     <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td width="2%">&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td><span class="titulos_lonuevo_regular"><center>¡$~SCRIPT VPS FIN~$!</span></td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 



<br>


 <center><a href="https://raw.githubusercontent.com/scriptmsc/scriptmsc/mscvip/script%20vps%20%2B%20PAYLOAD">SCRIPT AQUÍ</a></center>

<br>

         <td>&nbsp;</td> 

         <td><span class="texto_regular_recomienda"><center>Puertos activados por el script<br><br>

OpenSSH : 22 <br>
Dropbear : 443 <br>
Python : 1080 <br>
Squid3 : 8080, 3128 <br>
OpenVPN : TCP 1194 (client) <br>
badvpn : badvpn-udpgw port 7300 <br>
Apache : 81 </span></td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 

         <td height="2" class="linea_punteada"></td> 
         <td height="2" class="linea_punteada"></td> 
         <td width="2%" class="linea_punteada"></td> 
        </tr> 
        <tr> 
         <td height="1"></td> 
         <td height="1"></td> 
         <td width="2%"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
    <tr> 
     <td height="12" colspan="2"></td> 
    </tr> 
    <tr> 
     <td height="10"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td align="center"><img src="img/menu.png" width="282" height="452"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
    <tr> 
     <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td width="2%">&nbsp;</td> 
         <td>&nbsp;</td> 

         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td><span class="titulos_lonuevo_regular"><CENTER>MENÚ DEL SCRIPT</span></td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
    
     <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
      


        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td height="2" class="linea_punteada"></td> 
         <td height="2" class="linea_punteada"></td> 
         <td width="2%" class="linea_punteada"></td> 
        </tr> 
        <tr> 
         <td height="1"></td> 
         <td height="1"></td> 
         <td width="2%"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
    <tr> 
     <td height="12" colspan="2"></td> 
    </tr> 
    <tr> 
     <td height="10"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td align="center"><img src="img/admin.png" width="282" height="452"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
    <tr> 
     <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td width="2%">&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td><span class="titulos_lonuevo_regular"><center>ADMINISTRAR USUARIOS</span></td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 

         <td><span class="texto_regular_mo_recomienda"><center 
>Aquí podrás crear usuarios, poner banner a su vps, etc</span></td> 
         <td width="2%">&nbsp;</td> 


        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td height="2" class="linea_punteada"></td> 
         <td height="2" class="linea_punteada"></td> 
         <td width="2%" class="linea_punteada"></td> 
        </tr> 
        <tr> 
         <td height="1"></td> 
         <td height="1"></td> 
         <td width="2%"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
    <tr> 
     <td height="12" colspan="2"></td> 
    </tr> 
    <tr> 
     <td height="10"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td align="center"><img src="img/admvps.png" width="282" height="452"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
    <tr> 
     <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td width="2%">&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td><span class="titulos_lonuevo_regular"><CENTER>MENÚ DE VPS</span></td> 
         <td width="2%">&nbsp;</td> 
        </tr> 


<body background="imgs/fondo1.jpg"bgcolor="#99F3F6">


        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td><span class="texto_regular_mr_recomienda"><center>Aquí podrás instalar dropbear, squid, ssl, phyton, etc</span></td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td height="2" class="linea_punteada"></td> 
         <td height="2" class="linea_punteada"></td> 
         <td width="2%" class="linea_punteada"></td> 
        </tr> 
        <tr> 
         <td height="1"></td> 
         <td height="1"></td> 
         <td width="2%"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
    <tr> 
     <td height="12" colspan="2"></td> 
    </tr> 
    <tr> 
     <td height="10"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td align="center"><img src="img/herramientas.png" width="282" height="452"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
    <tr> 
     <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td width="2%">&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td><span class="titulos_lonuevo_regular"><center>MENÚ DE HERRAMIENTAS</span></td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td><span class="texto_regular_movistar_recomienda"><center>Aquí podrás activar BAN UDP 7300 para juegos online, Abrir y cerrar puertos de su vps</span></td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
         <td width="2%">&nbsp;</td> 
        </tr> 
        <tr> 
         <td height="2" class="linea_punteada"></td> 
         <td height="2" class="linea_punteada"></td> 
         <td width="2%" class="linea_punteada"></td> 
        </tr> 
        <tr> 
         <td height="1"></td> 
         <td height="1"></td> 
         <td width="2%"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
    <tr> 
     <td height="12" colspan="2"></td> 
    </tr> 
    <tr> 
     <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td width="2%">&nbsp;</td> 
         <td>&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td><span class="titulos_lonuevo_regular">Y mucho más...</span></td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td><span class="texto_regular_recomienda"> podrás :<br> </span><span class="texto_regular_">
           <ul> 
            

            <li class="arial_gris_15">1] CREAR USUARIOS OPENVPN </li> 
            <li class="arial_gris_15">- Integrado con menú de control de usuarios</li> 
            <li class="arial_gris_15">- Descargar aplicacion ⬇️⬇️</li> 
            
           </ul> </span></td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>
          <table width="100%" border="0" cellspacing="0" cellpadding="0"> 

           <tbody>
            <tr> 
             <td align="center" class="titulos_lonuevo_regular">OpenVPN Descárgala en Google Play ⬇️⬇️</td> 
             <td width="2%" align="center" class="titulos_lonuevo_regular">&nbsp;</td> 
            </tr> 
            <tr> 
             <td align="right">&nbsp;</td> 
             <td width="2%" align="right">&nbsp;</td> 
            </tr> 
            <tr> 
             <td>
              <div align="center">

<div align="center">
                   <a href="https://play.google.com/store/apps/details?id=net.openvpn.openvpn"><img src="img/playstore.jpg" width="94" height="34" border="0"></a>


             

             <td width="2%">&nbsp;</td> 
            </tr> 
           </tbody>
          </table> </td> 
        </tr> 
        <tr> 
         <td>&nbsp;</td> 
         <td>&nbsp;</td> 
        </tr> 
        <tr> 
         <td height="1"></td> 
         <td height="1"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
    <tr> 
     <td height="12" colspan="2"></td> 
    </tr> 
   </tbody>
  </table> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
   <tbody>
    <tr> 
     <td> <style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->






</style> </td>
        </tr>
        <tr> 
         <td> 
          <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
           <tbody>
            <tr> 
             <td height="8" bgcolor="#8cb336"></td> 
            </tr> 
            <tr> 
             <td height="2" bgcolor="#6fa627"></td> 
            </tr> 
            <tr> 
             <td height="80px">
              <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
               <tbody>
                <tr> 

                 <td width="25%" align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a></td> 

                 <td><img src="img/divi.png" width="5" height="86"></td> 
                 <td width="25%" align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a></td> 

                 <td><img src="img/divi.png" width="5" height="86"></td> 
                 <td width="25%" align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a></td>
 
                 <td><img src="img/divi.png" width="5" height="86"></td> 
                 <td width="25%" align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a></td> 


                </tr> 
                <tr> 
                 <td height="5" colspan="7" bgcolor="#CCCCCC"></td> 
                </tr> 
                <tr> 

                 <td width="25%" align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a><a href="#"></a></td> 

                 <td><img src="img/divi.png" width="5" height="86"></td> 
                 <td width="25%" align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a></td> 

                 <td><img src="img/divi.png" width="5" height="86"></td> 
                 <td align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a><a href="#"></a></td> 

                 <td><img src="img/divi.png" width="5" height="86"></td> 
                 <td width="25%" align="center" background="img/divi.pn"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a></td> 
                </tr> 
               </tbody>
              </table></td> 
            </tr> 
            <tr> 
             <td height="8" bgcolor="#8cb336"></td> 
            </tr> 
            <tr> 
             <td height="2" bgcolor="#6fa627"></td> 
            </tr> 
            <tr> 
             <td height="1" bgcolor="#FFFFFF"></td> 
            </tr> 
           </tbody>
          </table> </td> 
        </tr> 
       </tbody>
      </table> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td>
          <link href="css/estilos.css" rel="stylesheet" type="text/css"> 
          <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
           <tbody>
            <tr> 
             <td colspan="2">
              <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
               <tbody>
                <tr> 
                 <td align="center">
                  <div align="center">
                   <a href="https://www.facebook.com/groups/116823142324222/"><img src="img/msc.png" width="110" height="70" border="0"></a>



                  </div></td> 
                </tr> 
               </tbody>
              </table></td> 
            </tr> 
            <tr> 
             <td height="28" colspan="2" align="center"><span class="texto_footer">MSC PERÚ | VPS MSC</span></td> 
            </tr> 
            <tr> 
             <td height="17" colspan="2" align="center" class="linea_footer"><img src="#" width="176" height="17"></td> 


            </tr> 
            <tr> 
             <td colspan="2"></td> 
            </tr> 
           </tbody>
         </table>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script><script src="http://www.google-analytics.com/ga.js" type="text/javascript"></script><script src="http://www.google-analytics.com/ga.js" type="text/javascript"></script><script src="http://www.google-analytics.com/ga.js" type="text/javascript"></script><script src="http://www.google-analytics.com/ga.js" type="text/javascript"></script> <script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-8395096-3");
pageTracker._trackPageview();
} catch(err) {}
</script> </td> 


            


        </tr> 
       </tbody>
      </table> </td>
    </tr>
   </tbody>
  </table>
 
</body></html>