<?php
$endereco_web = "localhost";
$data_hora_atual = date("Y-m-d H:i:s");

$accessKEY = "06725231"; 

//Dados API SMS ClickAtell
$ClickAtellEnabled = 0 ;
$UserClickAtell = urlencode("jrmcassa");
$PassClickAtell = urlencode("jr519cas601");
$APIClickAtell   = urlencode("3599126");

//Dados API SMS LocaSMS
$LocaSMSEnabled = 1 ;
$UserLocaSMS = urlencode(" ");
$PassLocaSMS = urlencode(" ");


							
define('DEBUG', true);
error_reporting(E_ALL);
ini_set('display_errors', DEBUG ? 'On' : 'Off');
ini_set('log_errors', 0);
set_time_limit(0);
error_reporting(0);

#################################
  # EDIÇÃO OPCIONAL A PARTIR DAQUI
  #################################
  define("COR_PAGINA_LOGIN", "#37474F"); //em breve

  //para alterar o tema. Opcoes abaixo:
  //skin-blue   skin-blue-light   skin-yellow   skin-yellow-light
  //skin-green   skin-green-light   skin-purple   skin-purple-light
  //skin-red   skin-red-light   skin-black   skin-black-light
  define("SKIN_PAINEL_ADMINISTRADOR", "skin-red-light");
  define("SKIN_PAINEL_REVENDEDOR", "skin-red-light");

  date_default_timezone_set("America/Manaus");


	

?>