<?php
// Inclui o arquivo com o sistema de segurança
require_once("adm/system/seguranca.php");
expulsaSair();
?>
