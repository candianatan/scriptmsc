<!DOCTYPE html>
<html>
<head>
	<!-- EL PRESENTE EL ORIGINAL FUE HECHO CON CARIÑO PENSANDO EN USTED
		 TELEGRAM: t.me/mscperu
		 DATA: 26/10/2017
		 =================================================================
		         +++++++++++++++++ ATENCIÓN +++++++++++++++++++++ 
		 No hay que olvidar que no hay nada mejor que hacer.
		
		 ================================================================== 
	!-->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <title>Pagina Inicial</title>
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
</head>
<body>

<body background="assets/images/linux.jpg"bgcolor="#ECF0F1">


<div class="container">
        <div class="row justify-content-md-center">
            <div class="mbr-white col-md-10">
                <h1 class="mbr-section-title align-center mbr-bold pb-3 mbr-fonts-style display-1">MSC <> PERÚ</em></h1>
                <h3 class="mbr-section-subtitle align-center mbr-light pb-3 mbr-fonts-style display-2">BIENVENIDO | AREA DE DESCARGAS</h3>
                <p class="mbr-text align-center pb-3 mbr-fonts-style display-5">Entra en nuestro grupo de telegram y whatsap y quédate por las novedades que viene</p>
                <div class="mbr-section-btn align-center">

<a class="btn btn-md btn-primary display-4" href="./iniciar.php"><span class="socicon socicon-telegra mbr-iconfont mbr-iconfont-btn"></span>INICIAR SECCIÓN</a>

<a class="btn btn-md btn-primary display-4" href="https://t.me/joinchat/HfAEbhLyD4ifA3vszHjqbA"><span class="socicon socicon-telegram mbr-iconfont mbr-iconfont-btn"></span>GRUPO PUBLICO</a>
                    <a class="btn btn-md btn-primary display-4" href="https://chat.whatsapp.com/Ff8OFnCQgx0Efzw30SBAZZ"><span class="socicon socicon-telegra mbr-iconfont mbr-iconfont-btn"></span>GRUPO WHATSAP</a>
<br>
<a class="btn btn-sm btn-primary display-4" href="vpsmsc.php">
			<span class="mbri-login mbr-iconfont mbr-iconfont-btn"></span>VPS MSC</a>


</div>
            </div>
        </div>
    </div>

</section>

<section class="features3 cid-qz5p0sOupq" id="features3-j" data-rv-view="117">
<div class="container">
        <div class="media-container-row">
            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="assets/images/entel.jpg" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">ARCHIVO |  ENTEL</h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Descargue el mejor archivo para la aplicación HTTP INJETOR.
						<br>Después de descargar importe el archivo por la aplicación coloque el usuario y contraseña y pulse INICIAR</p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="adm/arquivos/entel.ehi" class="btn btn-primary display-4">DESCARGAR</a></div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="assets/images/claro.jpg" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">ARCHIVO | CLARO</h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                            Descargue el mejor archivo para la aplicación HTTP INJETOR.
						<br>Después de descargar importe el archivo por la aplicación coloque el usuario y contraseña y pulse INICIAR<br><br><br></p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="adm/arquivos/claro.ehi" class="btn btn-primary display-4">DESCARGAR</a></div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="assets/images/bitel.jpg" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7"><br><br>ARCHIVO | BITEL</h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                           Descargue el mejor archivo para la aplicación HTTP INJETOR.
						<br>Después de descargar importe el archivo por la aplicación coloque el usuario y contraseña y pulse INICIAR<br></p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="adm/arquivos/bitel.ehi" class="btn btn-primary display-4">DESCARGAR</a></div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="assets/images/download-225x225.jpg" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-7">APP | HTTP INJETOR<br></h4>
                        <p class="mbr-text mbr-fonts-style display-7">
                           Descarga directamente de playstore.
					   <br>Así mantiene los datos siempre actualizados.<br>
                       <br><br><br></p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="https://play.google.com/store/apps/details?id=com.evozi.injector" class="btn btn-primary display-4">DESCARGAR</a></div>
                </div>
            </div>
        </div>
    </div>
</section>
  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smooth-scroll/smooth-scroll.js"></script>
  <script src="assets/jarallax/jarallax.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
  </body>
</html>