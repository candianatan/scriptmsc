﻿<html xmlns="http://www.w3.org/1999/xhtml" class=" js cssanimations"><head> 
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
  <meta name="MSC VIP" content="true"> 
  <meta name="viewport" content="width=320 ,user-scalable=no"> 
  <meta name="description" content="Web MSC"> 
  <meta name="keywords" content="VPS , PAYLOAD, DROPLET, APK, SCRIPT MSV, ETC"> 
  <meta name="author" content="MSC | VIP"> 
  <title>MSC PERÚ | VPS </title> 
  <link href="../../css/estilos.css" rel="stylesheet" type="text/css"> 
  <style type="text/css">
<!--
* { margin:0; padding:0;}
img, fieldset, abbr {
	border:none;
}
ul,li{ list-style-type:none}
h1,h2,h3,h4,h5,h6 { font-size:1em;}
acronym, abbr { border-bottom: 1px dotted #333;cursor:help;}

body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}

.tabla_precios {
	max-width:100%;
	}
-->
</style> 
  <style type="text/css">#efectosCont .transp{position:absolute;left:0em;top:0em;width:100%;background-color:#000;height:100em;z-index:1000;font-size:1.3em;opacity:0.8; filter: alpha(opacity=80)}
</style> 
  <style>.contentsuperdestacados { background:transparent; height:27.2em;}.tpSubMenu .lstRight .txt { filter:progid:dximagetransform.microsoft.alpha(opacity=80); moz-opacity:0.8; opacity:0.8;}ul.othersLanguages { display:none; position:absolute; left:0; top:3.6em; width:7em; padding:1em; z-index:20; border:1px solid #48b1c7; border-top:0;}ul.othersLanguages li { float:none; margin-bottom:.5em;}.headercabecera h1.bold, .headercabecera h1.boldPeque, .headercabecera h1.reg, .headercabecera h1.prodbold, .headercabecera h1.prodreg { font-size:37px;}.contentcatalogo .destacados { height:25.3em; overflow:hidden}.intapoyo, .intlomasbuscado, .online { display:none;}.ocultaTabs { display:none;}.cabecera_producto .precioproducto span.titPuntos { display:none;}#gmap_coberturaWifi_op { display:none;}.cobertura_finder .ciudad { display:inline;}.cobertura_finder .lista_ejemplos {display:none;}.oculta_R, #wrapper .oculta_R,.descripVideo { display:none;}.cerrar_share { visibility:visible !important;}.form_ordenar .goTo, .detalles_producto,.toggle_hide { display:none;}.detalles_producto { display:none; position:static }.personalizacion .footer_personalizacion span { color:#fff }.list_prod_contratados .footer_prod_cont { display:block }.carrusel_ficha_prod .item-list ul {overflow:hidden}.rightcomunidad .plegado .tr {padding-bottom:0;} .rightcomunidad .plegado .archivo_blog ul {display:none} .rightcomunidad .plegado .archivo_blog h2 {background-image:url(../img/ico_arrowblue_r.gif);}.intconfigpuesto .n-ordenadores{height:8em;}</style> 
  <link href="../css/estilos.css" rel="stylesheet" type="text/css"> 
 </head> 
 <body>
  <div class="ns-box ns-other ns-effect-thumbslider ns-type-notice ns-show">
   <div class="ns-box-inner">
    
    <div class="ns-content">
     
    </div>
   </div>
   <span class="ns-close"></span>
  </div> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
   <tbody>
    <tr> 
     <td>

      <link rel="stylesheet" type="text/css" href="#"> 
      <link rel="stylesheet" type="text/css" href="#"> <style type="text/css">
<!--
.style1 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #FFFFFF;
}

	a.arial_12_cabezal:link {
	font: 12px Verdana, Arial, Helvetica, sans-serifl;color: #ffffff; text-decoration:none; }
a.arial_12_cabezal:hover {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #ffffff;text-decoration:underline; }	
a.arial_12_cabezal:visited {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #ffffff;text-decoration:underline; }
a.arial_12_cabezal:hover {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #ffffff;text-decoration:underline; }	
	
		a.arial_12_cabezal_azul:link {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #55c8e3; text-decoration:none; }
a.arial_12_cabezal_azul:hover {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #55c8e3;text-decoration:underline; }	
a.arial_12_cabezal_azul:visited {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #55c8e3;text-decoration:underline; }
a.arial_12_cabezal_azul:hover {
	font: 12px Verdana, Arial, Helvetica, sans-serif;color: #55c8e3;text-decoration:underline; }	
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style> 
      <table width="100%" height="37" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 

  <td width="34%" align="center" bgcolor="#00527a"><a href="sair.php" class="arial_12_cabezal">MSC</a></td> 

         <td width="2"><img src="#" width="2" height="39"></td>

         <td width="34%" align="center" bgcolor="#004262" class="arial_12_cabezal_azul"><a href="script.php" class="arial_12_cabezal_azul">SCRIPT</a></td> 
         
<td width="2"><img src="#" width="2" height="39"></td> 

 <td width="34%" align="center" bgcolor="#004262"><a href="mscssh.php" class="arial_12_cabezal_azul">SSH MSC</a></td>



      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 


         <td width="10" height="37" bgcolor="#00334e">&nbsp;</td> 
         <td bgcolor="#00334e"><span class="style1"><center>⚡~MSC VIP PERÚ~⚡</center></span></td> 
          
        


          
         <td width="10" bgcolor="#00334e">&nbsp;</td> 
        </tr> 
       </tbody>
      </table> <script>
			
					var notification = new NotificationFx({
						message : '<div class="ns-thumb"><img src="#"/></div><div class="ns-content"><p><a href="#" id="recbutton" onClick="pageTracker._trackEvent(\'express__\',\'clic\',\'flotante__boton__recargar\');"><img src="#"></a></p></div>',
						layout : 'other',
						ttl : 6000,
						effect : 'thumbslider',
						type : 'notice', // notice, warning, error or success
						onClose : function() {
							
						}
					});

					// show the notification
					notification.show();

			
</script> </td> 
    </tr> 
    <tr>
     <td> <style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style> </td>
    </tr>
    <tr> 
     <td> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td height="8" bgcolor="#8cb336"></td> 
        </tr> 
        <tr> 
         <td height="2" bgcolor="#6fa627"></td> 
        </tr> 
        <tr> 
         <td height="80px">
          <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
           <tbody>
            <tr style="height:80px;"> 
             <td width="25%" align="center" background="#" bgcolor="#00537B"><a href="https://chat.whatsapp.com/HWyspWXBOzp4XOuvdfgZiv"><img src="img/what.png" width="60" align="top" height="60" border="0"></a></td> 
             
<td><img src="#" width="2" height="80"></td> 

               <td width="25%" align="center" background="#" bgcolor="#00537B"><a href="https://www.facebook.com/groups/116823142324222/"><img src="img/face.png" width="63" align="top" height="63" border="0"></a></td> 



   <td><img src="#" width="2" height="80"></td> 
             <td width="25%" align="center" background="#" bgcolor="#00537B"><a href="https://www.youtube.com/channel/UCMfN61m6Y5El5nhtAYZy1pw"><img src="img/youtu.png" width="55" align="top" height="55" border="0"></a></td> 

       



<td><img src="#" width="2" height="80"></td> 

               <td width="25%" align="center" background="#" bgcolor="#00537B"><a href="https://chat.whatsapp.com/Ff8OFnCQgx0Efzw30SBAZZ"><img src="img/telegram.png" width="55" align="top" height="55" border="0"></a></td> 



             </tr> 
           </tbody>
          </table> </td> 
        </tr> 
        <tr> 
         <td height="8" bgcolor="#8cb336"></td> 
        </tr> 
        <tr> 
         <td height="2" bgcolor="#6fa627"></td> 
        </tr> 
        <tr> 
         <td height="1" bgcolor="#FFFFFF"></td> 
        </tr> 
       </tbody>
      </table> </td> 
    </tr> 
   </tbody>
  </table> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
   <tbody>
    <tr> 
     <td>
  
    <table width="100%" bgcolor="#D4E2E5" border="0" cellspacing="0" cellpadding="0"> 

      </table> </td> 
   
       

      <marquee scrollamount="10" behavior="alternate"> 
  <h3 class="card-title mbr-fonts-style display-9">ENTEL-BITEL-CLARO</h3>
 </marquee>


<div class="col-md-12 text-center" style="padding-top: 15px">
		<h1 style="font-size: 25pt; font-weight: bold"> ELLA NO TE AMA</h1>
		 </div>


	<div class="col-md-12 text-center" style="padding-top: 15px">
		<label class="label label-success">Transferencia rápida de datos</label>
		<label class="label label-warning">Servidores de alta velocidad</label>
		<label class="label label-info">Oculta tu IP</label>
		<label class="label label-primary">Compatible con Netflix</label>
		<label class="label label-warning">Servidores de todo el mundo</label>
		<label class="label label-success">Privacidad de internet</label>
		<label class="label label-info">Shell seguro exclusivo</label>
		<label class="label label-success">Compatible con Juegos online</label>
	</div>
	<div class="col-md-12 text-center" style="padding-top: 5px">
		<label class="label label-danger ">No DDOS</label>
		<label class="label label-danger">No Hacking</label>
		<label class="label label-danger">No Carding</label>
		<label class="label label-danger">No Spam</label>
		<label class="label label-danger">No Torrent</label>
		<label class="label label-danger">No Porno</label>
		<label class="label label-danger">No Ratas</label>
			
	</div>
	
<br>



<web msc>


 
 <script type="text/javascript">
var adfly_id = 17592767;
var adfly_advert = 'int';
var adfly_protocol = 'http';
var adfly_domain = 'adf.ly';
var domains = ['entel.pe','claro.com.pe','bitel.com.pe'];
var adfly_nofollow = true;
var frequency_cap = '5';
var frequency_delay = '5';
var init_delay = '3';
var popunder = true;
</script>
<script src="https://cdn.adf.ly/js/link-converter.js"></script>
<script src="https://cdn.adf.ly/js/entry.js"></script>

<script type="text/javascript"> 
    var adfly_id = 17592767; 
    var popunder_frequency_delay = 0; 
</script> 
<script src="http://cdn.adf.ly/js/display.js"></script> 
 




 <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
</head>
<body>


 <section class="features3 cid-qz5p0sOupq" id="features3-j" data-rv-view="117">
<div class="container">
        <div class="media-container-row">
            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">

                        <img src="./img/US.png" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                       <h4 class="card-title mbr-fonts-style display-9">VPS: EEUU 1<br></h4>
                        <p class="mbr-text mbr-fonts-style display-9">
                            IP:159.65.170.145
<br>
User: msc-btc<br>
Pass: msc-btc
<br>
Squid: 3128
<br>
Dropbear: 443
<br>
SSL: 444
<br>
Python: 1080
<br>
OpenSSH: 22
<br>

Max Login: 500
					   <br>
 	VENCE: 30/12/2018<br></p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="adm/arquivos/entel.ehi" class="btn btn-primary display-4">DESCARGAR OVPN</a></div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="./img/US.png" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-9">VPS: EEUU 2<br></h4>
                        <p class="mbr-text mbr-fonts-style display-9">
                            IP:158.69.142.242
<br>
User: msc-btc<br>
Pass: msc-btc
<br>
Squid: 3128
<br>
Dropbear: 443
<br>
SSL: 444
<br>
Python: 1080
<br>
OpenSSH: 22
<br>
Max Login: 500
					   <br>
 	VENCE: 30/12/2018<br></p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="adm/arquivos/claro.ehi" class="btn btn-primary display-4">DESCARGAR OVPN</a></div>
                </div>
            </div>
<div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="./img/CA.png" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-9"><br><br>VPS: CANADA 1</h4>
                        <p class="mbr-text mbr-fonts-style display-9">
                           IP:124.867.252.245
<br>
User: msc-btc<br>
Pass: msc-btc
<br>
Squid: 3128
<br>
Dropbear: 443
<br>
SSL: 444
<br>
Python: 1080
<br>
OpenSSH: 22
<br>
Max Login: 500
					   <br>
 	VENCE: 30/12/2018<br></p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="adm/arquivos/bitel.ehi" class="btn btn-primary display-4">DESCARGAR OVPN</a></div>
                </div>
            </div>

            <div class="card p-3 col-12 col-md-6 col-lg-3">
                <div class="card-wrapper">
                    <div class="card-img">
                        <img src="./img/CA.png" title="" media-simple="true">
                    </div>
                    <div class="card-box">
                        <h4 class="card-title mbr-fonts-style display-9"><br>VPS: CANADA 2<br></h4>
                        <p class="mbr-text mbr-fonts-style display-9">
                           IP:157.89.152.67
<br>
User: msc-btc<br>
Pass: msc-btc
<br>
Squid: 3128
<br>
Dropbear: 443
<br>
SSL: 444
<br>
Python: 1080
<br>
OpenSSH: 22
<br>
Max Login: 500
					   <br>
 	VENCE: 30/12/2018<br>
                       <br></p>
                    </div>
                    <div class="mbr-section-btn text-center"><a href="https://play.google.com/store/apps/details?id=com.evozi.injector" class="btn btn-primary display-4">DESCARGAR OVPN</a></div>
                </div>
            </div>
        </div>
    </div>
</section>
  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smooth-scroll/smooth-scroll.js"></script>
  <script src="assets/jarallax/jarallax.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
  </body>
</html>






 </tr> 
       </tbody>
      </table></td> 
    </tr> 
    <tr> 
     <td height="9" colspan="2"></td> 
    </tr> 
    <tr> 
<br>
     <td height="2" colspan="2" class="linea_punteada"></td> 
    </tr> 

        </tr> 

       </tbody>
      </table> </td> 
    </tr> 

       



 <center><h1>VIDEO PERÚANO</h1></td> </tr>
<br>
<center><video width="320" loop controls play="yes" src="video/chile.mp4"> 
  </video>


<hr>
<br>









 <tr bgcolor="#f6f6f6"> 
     <td height="29">
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 

       </tbody>
      </table> </td>
    </tr>
    <tr> 
     <td colspan="2">
      <table width="100%"> 
       <tbody>
        <tr> 



         <td widthH="54" heightT="56"><a href="#"><center><img src="img/ojo.png" width="160" height="130"></a></td> 
         <td width="10"></td> 
        
      




        </tr> 
       </tbody>
      </table></td> 
    </tr> 


    <tr> 
     <td height="10" colspan="2"></td> 
    </tr> 
    <tr> 
     <td height="2" colspan="2" class="linea_punteada"></td> 
    </tr> 
    <tr> 
  <br>
     <td height="2" colspan="2"></td> 
    </tr> 



 <FONDO DE PAGINAS>

<br>
<body background= "img/fondo2.png"bgcolor= "#99F3F6"> 




<html>

<b><font color="black"
 face="arial" size="3">&nbsp;</font></div></b>

<br>
<br>

<script>
function cambiarTrack(track) {
   var path =  track.getAttribute("path")
   viejo_audio = document.getElementById("reproductor")
   audio_padre = viejo_audio.parentNode
   audio_padre.removeChild(viejo_audio)
   nuevo_audio = document.createElement("audio")
   nuevo_audio.setAttribute("id","reproductor")
   nuevo_audio.setAttribute("controls", "controls")


  // nuevo_audio.setAttribute("autoplay", "autoplay")


   source = document.createElement("source")
   source.setAttribute("src", path)
   source.setAttribute("type", "audio/mpeg")
   source.setAttribute("id", "reproductorSource")
   nuevo_audio.appendChild(source)
   audio_padre.appendChild(nuevo_audio)}
function cargarReproductor() {
         var select = document.getElementById("selectTrack")
         var path = select.options[0].getAttribute("path")
   nuevo_audio = document.createElement("audio")
   nuevo_audio.setAttribute("id","reproductor")
   nuevo_audio.setAttribute("controls", "controls")       
   source = document.createElement("source")
   source.setAttribute("src", path)
   source.setAttribute("type", "audio/mpeg")
   source.setAttribute("id", "reproductorSource")
   nuevo_audio.appendChild(source)
   padre = document.getElementById("reproductorBox")
   padre.appendChild(nuevo_audio)
}
</script>
<center><style="width:88px;height:10px"><div id="reproductorBox"></div>
<select id = "selectTrack" multiple onchange="cambiarTrack(this.options[this.selectedIndex]);">
<option path="audio/merindo.mp3">Santana The Golden Boy - Me Rindo</option>

<option path="audio/mirarte.mp3">Como mirarte - remix sebastian yatra</option>
<option path="audio/starr.mp3">Sog start</option>
<option path="audio/sirena.mp3">Cali El Dande sirena</option>
</select>
<script>cargarReproductor();</script>
<br><br>
<br<

</html>


<title>CloudSSH - Free Premium SSH</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="asset/dist/js/sweetalert.css">


<div class="col-md-12 text-center" style="padding-top: 15px">
		<h1 style="font-size: 25pt; font-weight: bold">NO VENDER</h1>
		
		
	
	</div>
	<div class="col-md-12 text-center" style="padding-top: 15px">
		<label class="label label-success">Transferencia rápida de datos</label>
		<label class="label label-warning">Servidores de alta velocidad</label>
		<label class="label label-info">Ocultar tu IP</label>
		<label class="label label-primary">Server Netflix</label>
		<label class="label label-warning">Servidores de todo el mundo</label>
		<label class="label label-success">Privacidad de internet</label>
		<label class="label label-info">Shell seguro exclusivo</label>
		<label class="label label-success">Soluciones de seguridad</label>
	</div>
	<div class="col-md-12 text-center" style="padding-top: 5px">
		<label class="label label-danger ">No DDOS</label>
		<label class="label label-danger">No Hacking</label>
		<label class="label label-danger">No Carding</label>
		<label class="label label-danger">No Spam</label>
		<label class="label label-danger">No Torrent</label>
		<label class="label label-danger">No Porno</label>
		<label class="label label-danger">No Ratas</label>
			
	</div>
	
	




        </tr> 
       </tbody>
      </table></td> 
    </tr> 
    <tr> 
     <td height="24" colspan="2"></td> 
    </tr> 
   </tbody>
  </table> 
  <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
   <tbody>
    <tr> 
<br>
<br>

     <td> <style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->




<br>

<br>



</style> </td>
        </tr>
        <tr> 
         <td> 
          <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
           <tbody>
            <tr> 
             <td height="8" bgcolor="#8cb336"></td> 
            </tr> 
            <tr> 
             <td height="2" bgcolor="#6fa627"></td> 
            </tr> 
            <tr> 
             <td height="80px">
              <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
               <tbody>
                <tr> 

                 <td width="25%" align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a></td> 

                 <td><img src="img/divi.png" width="5" height="86"></td> 
                 <td width="25%" align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a></td> 

                 <td><img src="img/divi.png" width="5" height="86"></td> 
                 <td width="25%" align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a></td>
 
                 <td><img src="img/divi.png" width="5" height="86"></td> 
                 <td width="25%" align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a></td> 


                </tr> 
                <tr> 
                 <td height="5" colspan="7" bgcolor="#CCCCCC"></td> 
                </tr> 
                <tr> 

                 <td width="25%" align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a><a href="#"></a></td> 

                 <td><img src="img/divi.png" width="5" height="86"></td> 
                 <td width="25%" align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a></td> 

                 <td><img src="img/divi.png" width="5" height="86"></td> 
                 <td align="center" background="#"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a><a href="#"></a></td> 

                 <td><img src="img/divi.png" width="5" height="86"></td> 
                 <td width="25%" align="center" background="img/divi.pn"><a href="#"><img src="img/btc.png" width="60" height="60" border="0"></a></td> 
                </tr> 
               </tbody>
              </table></td> 
            </tr> 
            <tr> 
             <td height="8" bgcolor="#8cb336"></td> 
            </tr> 
            <tr> 
             <td height="2" bgcolor="#6fa627"></td> 
            </tr> 
            <tr> 
             <td height="1" bgcolor="#FFFFFF"></td> 
            </tr> 
           </tbody>
          </table> </td> 
        </tr> 
       </tbody>
      </table> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
       <tbody>
        <tr> 
         <td>
          <link href="css/estilos.css" rel="stylesheet" type="text/css"> 
          <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
           <tbody>
            <tr> 
             <td colspan="2">
              <table width="100%" border="0" cellspacing="0" cellpadding="0"> 
               <tbody>
                <tr> 
                 <td align="center">
                  <div align="center">
                   <a href="https://www.facebook.com/groups/116823142324222/"><imgg src="img/msc.png" width="110" height="70" border="0"></a>


                  </div></td> 
                </tr> 
               </tbody>
              </table></td> 
            </tr> 
            <tr> 


             


 
 <td width="30%" align="center" bgcolor="#D4E2E5"<h4 class="mbr-section-title align-center mbr-bold pb-3 mbr-fonts-style display-1">MSC PERÚ VPS</em></h4> 


            </tr> 
            <tr> 
             <td colspan="2"></td> 
            </tr> 
           </tbody>
         </table>





</td> 


            


        </tr> 
       </tbody>
      </table> </td>
    </tr>
   </tbody>
  </table>
 
</body></html>