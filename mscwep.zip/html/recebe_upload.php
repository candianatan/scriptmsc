<?php
$_UP['pasta'] = 'adm/arquivos/';
$_UP['tamanho'] = 1024 * 1024 * 2;
$_UP['extensoes'] = array('ehi');
$_UP['renomeia'] = false;

$_UP['erros'][0] = 'No hubo error';
$_UP['erros'][1] = 'El archivo en el upload es mayor que el límite de PHP';
$_UP['erros'][2] = 'El archivo supera el límite de tamaño especificado en el HTML';
$_UP['erros'][3] = 'La carga del archivo se hizo parcialmente';
$_UP['erros'][4] = 'No se ha cargado el archivo';
	if ($_FILES['arquivo']['error'] != 0) {
	die("No se pudo cargar, error: <br />" . $_UP['erros'][$_FILES['arquivo']['error']]);
	exit;
}
			$extensao = strtolower(end(explode('.', $_FILES['arquivo']['name'])));
				if (array_search($extensao, $_UP['extensoes']) === false) {
			echo "Por favor, envie archivos con las siguientes extensiones: ehi";
			}
				else if ($_UP['tamanho'] < $_FILES['arquivo']['size']) {
				echo "El archivo enviado es muy grande, envía archivos de hasta 2Mb.";
				}
				else {
				if ($_UP['renomeia'] == true) {
				$nome_final = time().'.ehi';
				} else {
				$nome_final = $_FILES['arquivo']['name'];
				}
						if (move_uploaded_file($_FILES['arquivo']['tmp_name'], $_UP['pasta'] . $nome_final)) {
							echo "¡Cargado efectuado con éxito!";
								header("Location: home.php");
						} else {
							echo "No se pudo enviar el archivo a la carpeta, vuelva a intentarlo";
								
								header("Location: home.php");
}
 
}
 
?>