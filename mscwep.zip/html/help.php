<?php
require_once("adm/system/funcoes.php");
require_once("adm/system/seguranca.php");
require_once("adm/system/config.php");
require_once("adm/system/classe.ssh.php");

protegePagina("admin");
if( $_SESSION['tipo'] == "user"){
	expulsaVisitante();			
}
		$data_atual = date("Y-m-d");
		$SQLAdministrador = "SELECT * FROM admin WHERE id_administrador = '".$_SESSION['usuarioID']."'";
        $SQLAdministrador = $conn->prepare($SQLAdministrador);
        $SQLAdministrador->execute();
        $administrador = $SQLAdministrador->fetch();
?>
<!DOCTYPE html>
<html>
<head>
    <!-- HECHO CON MSC
		 TELEGRAM: t.me/mscperu
		 DATA: 26/10/2017
		 =================================================================
		         +++++++++++++++++ ATENCIÓN +++++++++++++++++++++ 
		 MSC MSC MSC MSC MSC MSC MSC MSC MSC 
		 ================================================================== 
	!-->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <title>Soporte de Panel Upload | eliminar Archivos</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
</head>
<body>
<section class="menu cid-qzbHlxYkm4" once="menu" id="menu2-r" data-rv-view="175">
<nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-toggleable-sm bg-color transparent">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                
                <span class="navbar-caption-wrap"><a class="navbar-caption text-info display-5" href="home.php">MSC PERÚ</span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-primary display-4" href="home.php"><span class=" mbr-iconfont mbr-iconfont-btn"></span>
                    REGRESAR<br></a> <a class="btn btn-sm btn-primary display-4" href="sair.php"><span class="mbri-login mbr-iconfont mbr-iconfont-btn"></span>SALIR</a></div>
        </div>
    </nav>
</section>
<section class="mbr-section content5 cid-qzbJs49lsO mbr-jumbotron-background" id="content5-s" data-rv-view="177">
<div class="container">
        <div class="media-container-row">
            <div class="title col-12 col-md-8">
                <h2 class="align-center mbr-bold mbr-white pb-3 mbr-fonts-style display-1">SOPORTE</h2>
                <h3 class="mbr-section-subtitle align-center mbr-light mbr-white pb-3 mbr-fonts-style display-5">
                    MSC PERÚ</h3>    
            </div>
        </div>
    </div>
</section>

<section class="mbr-section article content11 cid-qzbKMD492W" id="content11-t" data-rv-view="180">
	<div class="container">
        <div class="media-container-row">
            <div class="mbr-text counter-container col-12 col-md-8 mbr-fonts-style display-7">
                <ol>
                    <li><strong></strong>&nbsp;- Bueno, usted no ha borrado el archivo antiguo como el nombre y el predeterminado para que la página de downoad encuentre su archivo cada vez que un nuevo archivo tenga que quitar el antiguo archivo con el siguiente comando con su servidor instalado msc perú abierto..</li>
                    <li><strong> ¡IMPORTE EL ARCHIVO YA BAJADO!</strong> - En primer lugar colocó el nombre predeterminado para que la página de descarga encuentre su archivo en el servidor<strong>&nbsp;El archivo tiene que estar todo minúscula &nbsp;Ejm</strong><strong>:&nbsp;<em>entel.ehi</em>&nbsp;si tiene entel.ehi no va vajar</strong><span style="font-size: 0.8rem;">.&nbsp;</span>&nbsp;</li>
					<li><strong>¿TODO QUE QUIERES VENDER O MANDA PARA UNA PERSONA TIENES QUE COLOCA UN NUEVO ARCHIVO?</strong>&nbsp;- En el caso de que el usuario no pueda acceder a la base de datos.</li>
				</ol>
            </div>
        </div>
    </div>
</section>
  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smooth-scroll/smooth-scroll.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/touch-swipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/jarallax/jarallax.min.js"></script>
  <script src="assets/theme/js/script.js"></script>
</body>
</html>